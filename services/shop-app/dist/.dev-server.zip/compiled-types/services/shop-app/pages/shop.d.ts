export default function Shop(): import("react").JSX.Element;
