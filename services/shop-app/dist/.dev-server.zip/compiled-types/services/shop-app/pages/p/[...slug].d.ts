declare function PDP(): import("react").JSX.Element;
declare namespace PDP {
    function getInitialProps(): Promise<{}>;
}
export default PDP;
