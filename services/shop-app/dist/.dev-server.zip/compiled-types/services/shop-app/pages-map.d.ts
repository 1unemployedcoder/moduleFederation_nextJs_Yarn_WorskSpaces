declare const _default: {
    '/shop': string;
    '/p/*': string;
};
export default _default;
