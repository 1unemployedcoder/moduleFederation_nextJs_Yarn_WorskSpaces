declare const _default: {
    '/admin': string;
};
export default _default;
