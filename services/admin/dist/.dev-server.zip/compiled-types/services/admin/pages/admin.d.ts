export default function Admin(): import("react").JSX.Element;
